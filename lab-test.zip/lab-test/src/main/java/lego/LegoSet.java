package lego;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Comparator;
import java.util.Objects;
import java.util.Set;
@NoArgsConstructor(access = AccessLevel.PRIVATE)
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class LegoSet implements Comparable<LegoSet>{
    public static final Comparator<LegoSet> COMPARATOR = new LegoSetComparator();

    @EqualsAndHashCode.Include
    private String code;
    private String name;
    private int bricks;
    private Theme theme;
    @ToString.Exclude
    private Set<Minifigures> minifigures;

    @Override
    public int compareTo(LegoSet o) {
        return Objects.compare(this,o,COMPARATOR);
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    @AllArgsConstructor
    @Getter
    @ToString
    @EqualsAndHashCode(onlyExplicitlyIncluded = true)
    public static class Minifigures {
        @EqualsAndHashCode.Include
        private String id;
        private String name;
        private int quantity;
    }
    public enum Theme{
        @JsonProperty("City") CITY,
        @JsonProperty("Harry Potter") HARRY_POTTER,
        @JsonProperty("Star Wars") STAR_WARS,
        @JsonProperty("Creator Expert") CREATOR_EXPERT
    }

    private static class LegoSetComparator implements Comparator<LegoSet> {
        @Override
        public int compare(LegoSet o1, LegoSet o2) {
            if (o1.bricks != o2.bricks){
                return -Integer.compare(o1.bricks,o2.bricks);
            }
            return CharSequence.compare(o1.code, o2.code);
        }
    }
}